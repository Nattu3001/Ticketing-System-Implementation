package com.ticketing.repository;

import com.ticketing.model.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Collection;
import java.util.List;

public interface TicketRepository extends JpaRepository<Ticket, Long> {
    List<Ticket> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
    List<Ticket> findByAgentId(Long agentId);
    long countByAgentIdAndStatusIn(Long agentId, Collection<Ticket.Status> statuses);
    long countByStatus(Ticket.Status status);
}
