package com.ticketing.config;

import com.ticketing.model.User;
import com.ticketing.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Creates demo accounts the first time the application starts. */
@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository users;
    private final PasswordEncoder encoder;

    public DataSeeder(UserRepository users, PasswordEncoder encoder) {
        this.users = users;
        this.encoder = encoder;
    }

    @Override
    public void run(String... args) {
        if (users.count() > 0) return;
        add("Admin User", "admin@demo.com", "admin123", User.Role.ADMIN, null);
        add("Tara Technical", "tech@demo.com", "agent123", User.Role.AGENT, "Technical");
        add("Bala Billing", "billing@demo.com", "agent123", User.Role.AGENT, "Billing");
        add("Anu Account", "account@demo.com", "agent123", User.Role.AGENT, "Account");
        add("Gopi General", "general@demo.com", "agent123", User.Role.AGENT, "General");
        add("Demo Customer", "customer@demo.com", "customer123", User.Role.CUSTOMER, null);
    }

    private void add(String name, String email, String pass, User.Role role, String expertise) {
        User u = new User();
        u.setFullName(name);
        u.setEmail(email);
        u.setPassword(encoder.encode(pass));
        u.setRole(role);
        u.setExpertise(expertise);
        users.save(u);
    }
}
