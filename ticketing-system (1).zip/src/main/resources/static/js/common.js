// Shared helpers used by every page
function getUser() {
  try { return JSON.parse(sessionStorage.getItem('user')); } catch (e) { return null; }
}

async function api(path, options = {}) {
  const user = getUser();
  const headers = Object.assign({ 'Content-Type': 'application/json' }, options.headers || {});
  if (user) headers['X-User-Id'] = user.id;
  const res = await fetch(path, Object.assign({}, options, { headers }));
  let data = null;
  try { data = await res.json(); } catch (e) { /* empty body */ }
  if (!res.ok) {
    throw new Error((data && data.message) || 'Request failed (' + res.status + ')');
  }
  return data;
}

function esc(text) {
  const d = document.createElement('div');
  d.textContent = text == null ? '' : String(text);
  return d.innerHTML;
}

function fmtDate(iso) {
  return iso ? new Date(iso).toLocaleString() : '';
}
