package com.ticketing.controller;

import com.ticketing.model.Message;
import com.ticketing.service.TicketService;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class ChatController {

    public record ChatPayload(Long senderId, String content) {}

    private final TicketService service;
    private final SimpMessagingTemplate template;

    public ChatController(TicketService service, SimpMessagingTemplate template) {
        this.service = service;
        this.template = template;
    }

    @MessageMapping("/ticket/{ticketId}/send")
    public void send(@DestinationVariable Long ticketId, ChatPayload payload) {
        Message saved = service.saveMessage(ticketId, payload.senderId(), payload.content());
        template.convertAndSend("/topic/ticket/" + ticketId, saved);
    }
}
