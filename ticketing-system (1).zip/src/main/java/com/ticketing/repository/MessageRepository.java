package com.ticketing.repository;

import com.ticketing.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {
    List<Message> findByTicketIdOrderBySentAtAsc(Long ticketId);
}
