package com.ticketing.controller;

import com.ticketing.model.Message;
import com.ticketing.model.Ticket;
import com.ticketing.model.User;
import com.ticketing.service.TicketService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Demo-level authentication: the browser sends the logged-in user's id in the
 * X-User-Id header. For production, replace this with JWT or Spring Security sessions.
 */
@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    public record NewTicket(String subject, String category, String description) {}

    private final TicketService service;

    public TicketController(TicketService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Ticket create(@RequestHeader(value = "X-User-Id", required = false) Long uid,
                         @RequestBody NewTicket body) {
        User user = service.requireUser(uid);
        return service.createTicket(user, body.subject(), body.category(), body.description());
    }

    @GetMapping("/mine")
    public List<Ticket> mine(@RequestHeader(value = "X-User-Id", required = false) Long uid) {
        return service.ticketsFor(service.requireUser(uid));
    }

    @PutMapping("/{id}/status")
    public Ticket status(@RequestHeader(value = "X-User-Id", required = false) Long uid,
                         @PathVariable Long id, @RequestParam Ticket.Status status) {
        return service.updateStatus(id, status, service.requireUser(uid));
    }

    @GetMapping("/{id}/messages")
    public List<Message> messages(@RequestHeader(value = "X-User-Id", required = false) Long uid,
                                  @PathVariable Long id) {
        return service.messagesFor(id, service.requireUser(uid));
    }

    @GetMapping("/report")
    public Map<String, Object> report(@RequestHeader(value = "X-User-Id", required = false) Long uid) {
        return service.report(service.requireUser(uid));
    }
}
