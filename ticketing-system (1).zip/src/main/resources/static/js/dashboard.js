const user = getUser();
if (!user) window.location.href = 'index.html';

const PRIORITY_ORDER = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
let tickets = [];
let current = null;      // ticket currently open
let stomp = null;        // active chat connection

document.getElementById('who').textContent = user.fullName + ' (' + user.role + ')';
document.getElementById('logout').addEventListener('click', () => {
  sessionStorage.removeItem('user');
  window.location.href = 'index.html';
});

if (user.role === 'CUSTOMER') document.getElementById('newTicketCard').classList.remove('hidden');
if (user.role === 'ADMIN') document.getElementById('reportCard').classList.remove('hidden');
if (user.role !== 'CUSTOMER') document.getElementById('statusRow').classList.remove('hidden');
document.getElementById('listTitle').textContent =
  user.role === 'CUSTOMER' ? 'My tickets' : user.role === 'AGENT' ? 'Assigned to me' : 'All tickets';

// ---------- ticket list ----------
async function loadTickets() {
  tickets = await api('/api/tickets/mine');
  if (user.role !== 'CUSTOMER') {
    tickets.sort((a, b) => PRIORITY_ORDER[b.priority] - PRIORITY_ORDER[a.priority]);
  }
  renderList();
}

function renderList() {
  const box = document.getElementById('ticketList');
  if (tickets.length === 0) {
    box.innerHTML = '<div class="empty">No tickets yet.</div>';
    return;
  }
  box.innerHTML = tickets.map((t) => `
    <div class="ticket ${current && current.id === t.id ? 'active' : ''}" data-id="${t.id}">
      <div class="t">#${t.id} ${esc(t.subject)}</div>
      <span class="badge p-${t.priority}">${t.priority}</span>
      <span class="badge s-${t.status}">${t.status.replace('_', ' ')}</span>
      <div class="meta">
        ${esc(t.category)} &middot; Customer: ${esc(t.customerName)} &middot;
        Agent: ${esc(t.agentName || 'Unassigned')}<br>${fmtDate(t.createdAt)}
      </div>
    </div>`).join('');
  box.querySelectorAll('.ticket').forEach((el) =>
    el.addEventListener('click', () => openTicket(Number(el.dataset.id))));
}

// ---------- new ticket (customer) ----------
document.getElementById('ticketForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const out = document.getElementById('ticketMsg');
  try {
    const t = await api('/api/tickets', {
      method: 'POST',
      body: JSON.stringify({
        subject: document.getElementById('subject').value,
        category: document.getElementById('category').value,
        description: document.getElementById('description').value
      })
    });
    out.className = 'msg ok';
    out.textContent = 'Ticket #' + t.id + ' created. Priority: ' + t.priority +
      ', assigned to: ' + (t.agentName || 'none yet');
    e.target.reset();
    await loadTickets();
  } catch (err) {
    out.className = 'msg error';
    out.textContent = err.message;
  }
});

// ---------- ticket detail and chat ----------
async function openTicket(id) {
  current = tickets.find((t) => t.id === id);
  renderList();
  document.getElementById('detailEmpty').classList.add('hidden');
  document.getElementById('detail').classList.remove('hidden');
  renderHead();

  const box = document.getElementById('chatBox');
  box.innerHTML = '';
  try {
    const msgs = await api('/api/tickets/' + id + '/messages');
    msgs.forEach(addBubble);
  } catch (err) {
    box.innerHTML = '<div class="empty">' + esc(err.message) + '</div>';
  }
  connectChat(id);
}

function renderHead() {
  const t = current;
  document.getElementById('detailHead').innerHTML = `
    <h3 style="margin:0 0 6px">#${t.id} ${esc(t.subject)}</h3>
    <span class="badge p-${t.priority}">${t.priority}</span>
    <span class="badge s-${t.status}">${t.status.replace('_', ' ')}</span>
    <p style="font-size:14px">${esc(t.description)}</p>
    <div class="meta" style="font-size:12px;color:#6b7280">
      Category: ${esc(t.category)} &middot; Customer: ${esc(t.customerName)} &middot;
      Agent: ${esc(t.agentName || 'Unassigned')}
      ${t.resolvedAt ? '<br>Resolved: ' + fmtDate(t.resolvedAt) : ''}
    </div>`;
  document.getElementById('statusSelect').value = t.status;
}

function addBubble(m) {
  const box = document.getElementById('chatBox');
  const div = document.createElement('div');
  div.className = 'bubble' + (m.senderId === user.id ? ' me' : '');
  div.innerHTML = '<small>' + esc(m.senderName) + ' (' + esc(m.senderRole) + ') &middot; ' +
    fmtDate(m.sentAt) + '</small>' + esc(m.content);
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function connectChat(ticketId) {
  if (stomp) { try { stomp.disconnect(); } catch (e) { /* ignore */ } }
  stomp = Stomp.over(new SockJS('/chat'));
  stomp.debug = null;
  stomp.connect({}, () => {
    stomp.subscribe('/topic/ticket/' + ticketId, (frame) => addBubble(JSON.parse(frame.body)));
  });
}

document.getElementById('chatForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text || !current || !stomp || !stomp.connected) return;
  stomp.send('/app/ticket/' + current.id + '/send', {},
    JSON.stringify({ senderId: user.id, content: text }));
  input.value = '';
});

document.getElementById('statusBtn').addEventListener('click', async () => {
  if (!current) return;
  try {
    const updated = await api('/api/tickets/' + current.id + '/status?status=' +
      document.getElementById('statusSelect').value, { method: 'PUT' });
    current = updated;
    await loadTickets();
    current = tickets.find((t) => t.id === updated.id) || updated;
    renderHead();
    if (user.role === 'ADMIN') loadReport();
  } catch (err) {
    alert(err.message);
  }
});

// ---------- report (admin) ----------
async function loadReport() {
  const r = await api('/api/tickets/report');
  const stats = Object.entries(r.byStatus).map(([k, v]) =>
    `<div class="stat"><b>${v}</b><span>${k.replace('_', ' ')}</span></div>`);
  stats.push(`<div class="stat"><b>${r.total}</b><span>TOTAL</span></div>`);
  stats.push(`<div class="stat"><b>${r.avgResolutionMinutes}</b><span>AVG MIN TO RESOLVE</span></div>`);
  document.getElementById('stats').innerHTML = stats.join('');
  document.getElementById('workload').innerHTML =
    '<tr><th>Agent</th><th>Expertise</th><th>Active tickets</th></tr>' +
    r.workload.map((w) => `<tr><td>${esc(w.agent)}</td><td>${esc(w.expertise)}</td><td>${w.active}</td></tr>`).join('');
}

loadTickets().catch((err) => alert(err.message));
if (user.role === 'ADMIN') loadReport().catch(() => {});
