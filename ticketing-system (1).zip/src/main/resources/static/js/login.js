const msg = document.getElementById('msg');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const tabLogin = document.getElementById('tabLogin');
const tabRegister = document.getElementById('tabRegister');

if (getUser()) window.location.href = 'dashboard.html';

function show(which) {
  const isLogin = which === 'login';
  loginForm.classList.toggle('hidden', !isLogin);
  registerForm.classList.toggle('hidden', isLogin);
  tabLogin.classList.toggle('active', isLogin);
  tabRegister.classList.toggle('active', !isLogin);
  msg.textContent = '';
}
tabLogin.addEventListener('click', () => show('login'));
tabRegister.addEventListener('click', () => show('register'));

function setMsg(text, ok) {
  msg.textContent = text;
  msg.className = 'msg ' + (ok ? 'ok' : 'error');
}

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const user = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        email: document.getElementById('loginEmail').value,
        password: document.getElementById('loginPassword').value
      })
    });
    sessionStorage.setItem('user', JSON.stringify(user));
    window.location.href = 'dashboard.html';
  } catch (err) {
    setMsg(err.message, false);
  }
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        fullName: document.getElementById('regName').value,
        email: document.getElementById('regEmail').value,
        password: document.getElementById('regPassword').value
      })
    });
    show('login');
    setMsg('Registration successful. Please log in.', true);
  } catch (err) {
    setMsg(err.message, false);
  }
});
