# Ticketing System

A web-based support ticketing system built with Java 17, Spring Boot, JPA (H2 database),
WebSocket (STOMP) and a plain HTML/CSS/JavaScript interface.

## Features
- Customer registration and login (passwords hashed with BCrypt)
- Customer portal: raise tickets, track status, chat with the assigned agent
- Automatic priority detection and automatic assignment to an available agent with matching expertise (least busy first)
- Agent dashboard: assigned tickets sorted by priority, status updates, real-time chat
- Admin view: all tickets plus reports (tickets by status, average resolution time, agent workload)
- Ticket status history stored in the database

## Run
Requirements: JDK 17+ and Maven 3.8+.

    mvn spring-boot:run

Open http://localhost:8080

| Role     | Email                | Password    |
|----------|----------------------|-------------|
| Customer | customer@demo.com    | customer123 |
| Agent    | tech@demo.com        | agent123    |
| Admin    | admin@demo.com       | admin123    |

Other agents: billing@demo.com, account@demo.com, general@demo.com (password agent123).
The H2 console is available at http://localhost:8080/h2-console (JDBC URL jdbc:h2:file:./data/ticketdb, user sa, empty password).

## Project structure
    src/main/java/com/ticketing/
      config/       WebSocketConfig, AppConfig, DataSeeder
      controller/   AuthController, TicketController, ChatController
      model/        User, Ticket, Message, TicketHistory
      repository/   Spring Data JPA repositories
      service/      TicketService (priority, routing, status, reports)
    src/main/resources/static/   HTML, CSS and JavaScript interface

## Notes
Authentication is kept simple for learning purposes (the browser sends the user id in a header).
For production use, replace it with Spring Security and JWT/session authentication.
