package com.ticketing.controller;

import com.ticketing.model.User;
import com.ticketing.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    public record RegisterRequest(String fullName, String email, String password) {}
    public record LoginRequest(String email, String password) {}

    private final UserRepository users;
    private final PasswordEncoder encoder;

    public AuthController(UserRepository users, PasswordEncoder encoder) {
        this.users = users;
        this.encoder = encoder;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public User register(@RequestBody RegisterRequest req) {
        if (req.fullName() == null || req.fullName().isBlank()
                || req.email() == null || !req.email().contains("@")
                || req.password() == null || req.password().length() < 6) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Enter a name, a valid e-mail and a password of at least 6 characters");
        }
        String email = req.email().trim().toLowerCase();
        if (users.findByEmail(email).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "E-mail is already registered");
        }
        User u = new User();
        u.setFullName(req.fullName().trim());
        u.setEmail(email);
        u.setPassword(encoder.encode(req.password()));
        u.setRole(User.Role.CUSTOMER);
        return users.save(u);
    }

    @PostMapping("/login")
    public User login(@RequestBody LoginRequest req) {
        User u = users.findByEmail(req.email() == null ? "" : req.email().trim().toLowerCase())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid e-mail or password"));
        if (!encoder.matches(req.password() == null ? "" : req.password(), u.getPassword())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid e-mail or password");
        }
        return u;
    }
}
