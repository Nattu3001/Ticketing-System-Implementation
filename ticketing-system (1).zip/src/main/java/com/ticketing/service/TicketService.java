package com.ticketing.service;

import com.ticketing.model.*;
import com.ticketing.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class TicketService {

    private static final List<Ticket.Status> ACTIVE =
            List.of(Ticket.Status.ASSIGNED, Ticket.Status.IN_PROGRESS);

    private final TicketRepository tickets;
    private final UserRepository users;
    private final MessageRepository messages;
    private final HistoryRepository history;

    public TicketService(TicketRepository tickets, UserRepository users,
                         MessageRepository messages, HistoryRepository history) {
        this.tickets = tickets;
        this.users = users;
        this.messages = messages;
        this.history = history;
    }

    // ---------- users and access ----------

    public User requireUser(Long id) {
        if (id == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please log in");
        }
        return users.findById(id).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Unknown user"));
    }

    public Ticket requireAccess(Long ticketId, User user) {
        Ticket t = tickets.findById(ticketId).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Ticket not found"));
        boolean allowed = user.getRole() == User.Role.ADMIN
                || (user.getRole() == User.Role.CUSTOMER && user.getId().equals(t.getCustomerId()))
                || (user.getRole() == User.Role.AGENT && user.getId().equals(t.getAgentId()));
        if (!allowed) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You cannot access this ticket");
        }
        return t;
    }

    // ---------- tickets ----------

    @Transactional
    public Ticket createTicket(User customer, String subject, String category, String description) {
        if (customer.getRole() != User.Role.CUSTOMER) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Only customers can raise tickets");
        }
        if (isBlank(subject) || isBlank(category) || isBlank(description)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Subject, category and description are required");
        }
        Ticket t = new Ticket();
        t.setSubject(subject.trim());
        t.setCategory(category.trim());
        t.setDescription(description.trim());
        t.setCustomerId(customer.getId());
        t.setCustomerName(customer.getFullName());
        t.setPriority(detectPriority(subject + " " + description));
        t = tickets.save(t);
        history.save(new TicketHistory(t.getId(), null, "OPEN", customer.getId()));
        assignAgent(t);
        return t;
    }

    /** Keyword based prioritisation. */
    Ticket.Priority detectPriority(String text) {
        String s = text.toLowerCase();
        if (s.contains("down") || s.contains("breach") || s.contains("hacked")) return Ticket.Priority.CRITICAL;
        if (s.contains("error") || s.contains("urgent") || s.contains("failed")) return Ticket.Priority.HIGH;
        if (s.contains("how to") || s.contains("question") || s.contains("suggestion")) return Ticket.Priority.LOW;
        return Ticket.Priority.MEDIUM;
    }

    /** Automated routing: expertise match, then the agent with the fewest active tickets. */
    private void assignAgent(Ticket t) {
        List<User> candidates = users.findByRoleAndExpertiseAndAvailableTrue(User.Role.AGENT, t.getCategory());
        if (candidates.isEmpty()) {
            candidates = users.findByRoleAndExpertiseAndAvailableTrue(User.Role.AGENT, "General");
        }
        candidates.stream()
                .min(Comparator.comparingLong(a -> tickets.countByAgentIdAndStatusIn(a.getId(), ACTIVE)))
                .ifPresent(agent -> {
                    t.setAgentId(agent.getId());
                    t.setAgentName(agent.getFullName());
                    t.setStatus(Ticket.Status.ASSIGNED);
                    tickets.save(t);
                    history.save(new TicketHistory(t.getId(), "OPEN", "ASSIGNED", agent.getId()));
                });
    }

    public List<Ticket> ticketsFor(User user) {
        return switch (user.getRole()) {
            case CUSTOMER -> tickets.findByCustomerIdOrderByCreatedAtDesc(user.getId());
            case AGENT -> tickets.findByAgentId(user.getId());
            case ADMIN -> tickets.findAll();
        };
    }

    @Transactional
    public Ticket updateStatus(Long ticketId, Ticket.Status status, User user) {
        if (user.getRole() == User.Role.CUSTOMER) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Customers cannot change status");
        }
        Ticket t = requireAccess(ticketId, user);
        String old = t.getStatus().name();
        t.setStatus(status);
        if (status == Ticket.Status.RESOLVED || status == Ticket.Status.CLOSED) {
            if (t.getResolvedAt() == null) t.setResolvedAt(LocalDateTime.now());
        } else {
            t.setResolvedAt(null);
        }
        history.save(new TicketHistory(t.getId(), old, status.name(), user.getId()));
        return tickets.save(t);
    }

    // ---------- messages ----------

    public List<Message> messagesFor(Long ticketId, User user) {
        requireAccess(ticketId, user);
        return messages.findByTicketIdOrderBySentAtAsc(ticketId);
    }

    @Transactional
    public Message saveMessage(Long ticketId, Long senderId, String content) {
        User sender = requireUser(senderId);
        requireAccess(ticketId, sender);
        if (isBlank(content)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Message is empty");
        }
        Message m = new Message();
        m.setTicketId(ticketId);
        m.setSenderId(sender.getId());
        m.setSenderName(sender.getFullName());
        m.setSenderRole(sender.getRole().name());
        m.setContent(content.trim());
        return messages.save(m);
    }

    // ---------- reports ----------

    public Map<String, Object> report(User user) {
        if (user.getRole() != User.Role.ADMIN) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Admins only");
        }
        Map<String, Object> r = new LinkedHashMap<>();
        Map<String, Long> byStatus = new LinkedHashMap<>();
        for (Ticket.Status s : Ticket.Status.values()) {
            byStatus.put(s.name(), tickets.countByStatus(s));
        }
        r.put("byStatus", byStatus);
        r.put("total", tickets.count());

        double avg = tickets.findAll().stream()
                .filter(t -> t.getResolvedAt() != null)
                .mapToLong(t -> Duration.between(t.getCreatedAt(), t.getResolvedAt()).toMinutes())
                .average().orElse(0);
        r.put("avgResolutionMinutes", Math.round(avg * 10) / 10.0);

        List<Map<String, Object>> workload = new ArrayList<>();
        for (User a : users.findByRole(User.Role.AGENT)) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("agent", a.getFullName());
            row.put("expertise", a.getExpertise());
            row.put("active", tickets.countByAgentIdAndStatusIn(a.getId(), ACTIVE));
            workload.add(row);
        }
        r.put("workload", workload);
        return r;
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
