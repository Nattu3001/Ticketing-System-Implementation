package com.ticketing.repository;

import com.ticketing.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User> findByRoleAndExpertiseAndAvailableTrue(User.Role role, String expertise);
    List<User> findByRole(User.Role role);
}
